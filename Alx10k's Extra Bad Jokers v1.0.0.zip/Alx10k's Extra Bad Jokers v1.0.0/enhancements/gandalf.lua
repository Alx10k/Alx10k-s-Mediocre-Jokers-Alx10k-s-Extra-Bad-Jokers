SMODS.Enhancement {
    key = 'gandalf',
    pos = { x = 0, y = 0 },
    config = {
        mult = 50,
        bonus = 50
    },
    loc_txt = {
        name = 'Gandalf',
        text = {
        [1] = '{C:blue}+50{} Chips AND {C:red}+50{} Mult'
    }
    },
    atlas = 'CustomEnhancements',
    any_suit = false,
    replace_base_card = false,
    no_rank = false,
    no_suit = false,
    always_scores = false,
    unlocked = true,
    discovered = false,
    no_collection = false,
    weight = 5
}