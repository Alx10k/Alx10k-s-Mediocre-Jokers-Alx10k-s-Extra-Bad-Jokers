SMODS.Seal {
    key = 'jokerseal',
    pos = { x = 0, y = 0 },
    badge_colour = HEX('DC143C'),
   loc_txt = {
        name = 'Joker Seal',
        label = 'Joker Seal',
        text = {
        [1] = 'Creates a {C:dark_edition}Negative, Perishable{} {C:attention}Joker{} when scored.',
        [2] = 'It is {C:attention}destroyed{} after.'
    }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = false,
    no_collection = false,
    calculate = function(self, card, context)
        if context.destroy_card and context.cardarea == G.play and context.destroy_card == card and card.should_destroy then
            G.E_MANAGER:add_event(Event({
                func = function()
                    card:start_dissolve()
                    return true
                end
            }))
            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Card Destroyed!", colour = G.C.RED})
            return
        end
        if context.main_scoring and context.cardarea == G.play then
            card.should_destroy = false
            local created_joker = true
                G.E_MANAGER:add_event(Event({
                    func = function()
                        local joker_card = SMODS.add_card({ set = 'Joker' })
                        if joker_card then
                            joker_card:set_edition("e_negative", true)
                            joker_card:add_sticker('perishable', true)
                        end
                        
                        return true
                    end
                }))
            card.should_destroy = true
            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = created_joker and localize('k_plus_joker') or nil, colour = G.C.BLUE})
        end
    end
}