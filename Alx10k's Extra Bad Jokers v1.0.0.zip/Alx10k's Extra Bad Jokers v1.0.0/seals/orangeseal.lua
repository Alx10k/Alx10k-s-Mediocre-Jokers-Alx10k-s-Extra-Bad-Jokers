SMODS.Seal {
    key = 'orangeseal',
    pos = { x = 1, y = 0 },
    config = {
        extra = {
            levels = 2
        }
    },
    badge_colour = HEX('FF4500'),
   loc_txt = {
        name = 'Orange Seal',
        label = 'Orange Seal',
        text = {
        [1] = 'When scored, level up {C:attention}most played hand twice{},',
        [2] = 'but destroy this card.'
    }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = false,
    no_collection = false,
    calculate = function(self, card, context)
        if context.destroy_card and context.cardarea == G.play and context.destroy_card == card and card.should_destroy then
            G.E_MANAGER:add_event(Event({
                func = function()
                    card:start_dissolve()
                    return true
                end
            }))
            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Card Destroyed!", colour = G.C.RED})
            return
        end
        if context.main_scoring and context.cardarea == G.play then
            card.should_destroy = false
            local target_hand
                
                local temp_played = 0
                local temp_order = math.huge
                for hand, value in pairs(G.GAME.hands) do 
                  if value.played > temp_played and value.visible then
                    temp_played = value.played
                    temp_order = value.order
                    target_hand = hand
                  elseif value.played == temp_played and value.visible then
                    if value.order < temp_order then
                      temp_order = value.order
                      target_hand = hand
                    end
                  end
                end
            card.should_destroy = true
            SMODS.calculate_effect({level_up = card.ability.seal.extra.levels,
                level_up_hand = target_hand}, card)
            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_level_up_ex'), colour = G.C.RED})
        end
    end
}