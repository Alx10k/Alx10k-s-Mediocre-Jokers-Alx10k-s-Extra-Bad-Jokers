SMODS.Joker{ --Depressed Andy
    key = "depressedandy",
    config = {
        extra = {
            discards = 10,
            hands = 1,
            permanent = 0
        }
    },
    loc_txt = {
        ['name'] = 'Depressed Andy',
        ['text'] = {
            [1] = 'Gain {C:attention}10{} {C:red}Discards{}',
            [2] = 'but sets {C:blue}Hands{} to {C:attention}1{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["alextra_extrabad_jokers"] = true },

    calculate = function(self, card, context)
        if context.setting_blind  then
                return {
                    func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(card.ability.extra.discards).." Discard", colour = G.C.ORANGE})
                
        G.GAME.round_resets.discards = G.GAME.round_resets.discards + card.ability.extra.discards
        ease_discard(card.ability.extra.discards)
        
                return true
            end,
                    extra = {
                        func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Set to "..tostring(card.ability.extra.hands).." Hands", colour = G.C.BLUE})
                
        G.GAME.round_resets.hands = card.ability.extra.hands
        ease_hands_played(card.ability.extra.hands - G.GAME.current_round.hands_left)
        
                return true
            end,
                        colour = G.C.GREEN
                        }
                }
        end
    end
}