SMODS.Joker{ --Exponential Joker
    key = "exponentialjoker",
    config = {
        extra = {
            emult = 2
        }
    },
    loc_txt = {
        ['name'] = 'Exponential Joker',
        ['text'] = {
            [1] = '{X:legendary,C:white}^2{} Mult'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 12,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["alextra_extrabad_jokers"] = true },

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    e_mult = card.ability.extra.emult
                }
        end
    end
}