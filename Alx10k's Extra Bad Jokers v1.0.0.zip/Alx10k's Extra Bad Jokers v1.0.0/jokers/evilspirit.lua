SMODS.Joker{ --Evil Spirit
    key = "evilspirit",
    config = {
        extra = {
            Xmult = -0.75
        }
    },
    loc_txt = {
        ['name'] = 'Evil Spirit',
        ['text'] = {
            [1] = '{X:red,C:white}-X.75{} Mult',
            [2] = '{s:.7,C:inactive}He\'s evil what did you expect{}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 5,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = -12,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["alextra_extrabad_jokers"] = true },

    set_ability = function(self, card, initial)
        card:set_eternal(true)
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    Xmult = card.ability.extra.Xmult
                }
        end
    end
}