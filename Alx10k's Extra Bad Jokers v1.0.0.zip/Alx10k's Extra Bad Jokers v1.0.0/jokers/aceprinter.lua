SMODS.Joker{ --Ace Printer
    key = "aceprinter",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Ace Printer',
        ['text'] = {
            [1] = 'When {C:attention}blind is selected{}',
            [2] = 'add an {C:spades}Ace of Spades{}',
            [3] = 'to your deck.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["alextra_extrabad_jokers"] = true },

    calculate = function(self, card, context)
        if context.setting_blind  then
                local card_front = G.P_CARDS.S_A
            local new_card = create_playing_card({
                front = card_front,
                center = G.P_CENTERS.c_base
            }, G.discard, true, false, nil, true)
            
            G.E_MANAGER:add_event(Event({
                func = function()
                    new_card:start_materialize()
                    G.play:emplace(new_card)
                    return true
                end
            }))
                return {
                    func = function()
                G.E_MANAGER:add_event(Event({
                    func = function()
                        G.deck.config.card_limit = G.deck.config.card_limit + 1
                        return true
                    end
                }))
                draw_card(G.play, G.deck, 90, 'up')
                SMODS.calculate_context({ playing_card_added = true, cards = { new_card } })
            end,
                    message = "Added Card!"
                }
        end
    end
}