SMODS.Joker{ --Guillotine
    key = "guillotine",
    config = {
        extra = {
            Xmult = 10
        }
    },
    loc_txt = {
        ['name'] = 'Guillotine',
        ['text'] = {
            [1] = 'When a {C:attention}face card{} is played',
            [2] = 'give {X:red,C:white}X10{} Mult and',
            [3] = '{C:attention}destroy{} it.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["alextra_mycustom_jokers"] = true },

    calculate = function(self, card, context)
        if context.destroy_card and context.destroy_card.should_destroy  then
            return { remove = true }
        end
        if context.individual and context.cardarea == G.play  then
            context.other_card.should_destroy = false
            if context.other_card:is_face() then
                context.other_card.should_destroy = true
                return {
                    Xmult = card.ability.extra.Xmult,
                    extra = {
                        message = "Destroyed!",
                        colour = G.C.RED
                        }
                }
            end
        end
    end
}