SMODS.Joker{ --Card from Plasma Deck
    key = "cardfromplasmadeck",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Card from Plasma Deck',
        ['text'] = {
            [1] = 'Gives the effect of {C:attention}Plasma Deck{}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 3,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["alextra_extrabad_jokers"] = true },

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    balance = true
                }
        end
    end
}