--The Atlas
SMODS.Atlas {
	key = "ALJO",
	path = "jokers.png",
	px = 71,
	py = 95
}

SMODS.Atlas {
	key = "ALSOUL",
	path = "bob soul.png",
	px = 71,
	py = 95
}

SMODS.Atlas {
	key = "ALDOLLA",
	path = "dollar.png",
	px = 71,
	py = 95
}

--Bob Soul
SMODS.Consumable({
    key = "ALSOUL",
    set = "Spectral",
    object_type = "Consumable",
    name = "ALSOUL",
    loc_txt = {
        name = "The Soul?",
        text={
			"Creates a",
			"{C:legendary,E:1}Legendary{} Joker",
			"{C:inactive}(Must have room)"
        },
    },
    config = {chance = 1},
    loc_vars = function(self, info_queue, card)
        return {vars = {G.GAME.probabilities.normal, (card.ability or self.config).chance}}
    end,
	pos = {x=0, y=0},
	soul_pos = {x=0, y=1},
	order = 99,
	atlas = "ALSOUL",
    unlocked = true,
    cost = 4,

    use = function(self, card, area, copier)
        if pseudorandom('ALSOUL') < (G.GAME.probabilities.normal / card.ability.chance) then
            local card = create_card('Joker', G.Jokers, nil, nil, nil, nil, nil, 'AlBob')
            card:add_to_deck()
            G.jokers:emplace(card)
        else
            -- copied from wheel of fortune
            G.E_MANAGER:add_event(Event({trigger = 'after', delay = 0.4, func = function()
                attention_text({
                    text = localize('k_nope_ex'),
                    scale = 1.3, 
                    hold = 1.4,
                    major = card,
                    backdrop_colour = G.C.SECONDARY_SET.Tarot,
                    align = (G.STATE == G.STATES.TAROT_PACK or G.STATE == G.STATES.SPECTRAL_PACK) and 'tm' or 'cm',
                    offset = {x = 0, y = (G.STATE == G.STATES.TAROT_PACK or G.STATE == G.STATES.SPECTRAL_PACK) and -0.2 or 0},
                    silent = true
                    })
                    G.E_MANAGER:add_event(Event({trigger = 'after', delay = 0.06*G.SETTINGS.GAMESPEED, blockable = false, blocking = false, func = function()
                        play_sound('tarot2', 0.76, 0.4);return true end}))
                    play_sound('tarot2', 1, 0.4)
                    card:juice_up(0.3, 0.5)
            return true end }))
        end
    end,

    can_use = function(self, card)
        if #G.jokers.cards < G.jokers.config.card_limit then
            return true
        end
	end,

	check_for_unlock = function(self, args)
		if args.type == "win_deck" then
            unlock_card(self)
        else
			unlock_card(self)
		end
	end,
})

--1 dollar
SMODS.Consumable({
    key = "AlDolla",
    set = "Tarot",
    object_type = "Consumable",
    name = "AlDollar",
    loc_txt = {
        name = "1 Dollar",
        text={
        "Gain {C:attention}$#1#{}",
        },
    },
	
	
	pos = {x=0, y= 0},
	atlas = "ALDOLLA",
    unlocked = true,
    cost = 1,
    hidden = true,

    config = { extra = {dollaramt = 1}},

    loc_vars = function(self, info_queue, center)
		return { vars = { center.ability.extra.dollaramt }  }
	end,

    use = function(self, card, area, copier)
        ease_dollars(card.ability.extra.dollaramt)
    end,

    can_use = function(self, card)
        return true
	end,

	check_for_unlock = function(self, args)
		if args.type == "win_deck" then
            unlock_card(self)
        else
			unlock_card(self)
		end
	end,
})

-- Alx10k Joker
SMODS.Joker {
	key = 'AlAlx',
	loc_txt = {
		name = 'Alx10k',
		text = {
			"Has a {C:green}#2# in #3# {} chance",
			"to give {X:mult,C:white}X#1# {} for each",
			"played hand."
		}
	},
	config = {extra = {Xmult = 10, odds = 10}},
	rarity = 3,
	atlas = 'ALJO',
	pos = {x = 0, y = 0},
	cost = 7,
	unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
	loc_vars = function(self, info_queue, card)
		return { vars = { card.ability.extra.Xmult, (G.GAME.probabilities.normal or 1), card.ability.extra.odds } }
	end,
	calculate = function(self, card, context)
		if pseudorandom('AlAlx') < G.GAME.probabilities.normal / card.ability.extra.odds then
			if context.joker_main then
				return {
					message = localize { type = 'variable', key = 'a_xmult', vars = { card.ability.extra.Xmult } },
					Xmult_mod = card.ability.extra.Xmult
				}
			end
		end
	end
}

--Gandalf (featuring code stolen from yaha mouse)
SMODS.Joker{
    key = 'AlGandalf',
    loc_txt= {
        name = 'Gandalf',
        text = { "Gives either",
                "{C:blue}+#1#{} Chips",
                "OR {C:red}+#2#{} Mult",}
    },
    atlas = 'ALJO',
    rarity = 2,
    cost = 7,
    pos = {x=1, y= 0},
    config = { extra = {chips = 50, mult = 50}},
	unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = false,
	loc_vars = function(self, info_queue, center)
		return { vars = { center.ability.extra.chips, center.ability.extra.mult }  }
	end,
    calculate = function(self, card, context)
    if context.joker_main then
        if math.random(1,2) == 1 then
            return {
                chip_mod = card.ability.extra.chips,
				message = localize { type = 'variable', key = 'a_chips', vars = { card.ability.extra.chips } }
            }
        else
            return {
				mult_mod = card.ability.extra.mult,
				message = localize { type = 'variable', key = 'a_mult', vars = { card.ability.extra.mult } }
            }
        end
    end
end,
}

--Geeked
SMODS.Joker {
	key = 'AlGeeked',
	loc_txt = {
		name = 'Geeked',
		text = {
			"Gains {C:chips}+#2#{} Chip",
			"for each hand played.",
			"{s:0.8,C:inactive}(Currently {s:0.8,C:chips}+#1#{s:0.8,C:inactive} Chips)"
		}
	},
	config = { extra = { chips = 0, chip_gain = 10 } },
	rarity = 2,
	atlas = 'ALJO',
	pos = { x = 2, y = 0 },
	cost = 5,
	unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
	loc_vars = function(self, info_queue, card)
		return { vars = { card.ability.extra.chips, card.ability.extra.chip_gain } }
	end,
	calculate = function(self, card, context)
		if context.joker_main then
			return {
				chip_mod = card.ability.extra.chips,
				message = localize { type = 'variable', key = 'a_chips', vars = { card.ability.extra.chips } }
			}
		end
		if context.before and not context.blueprint then
			card.ability.extra.chips = card.ability.extra.chips + card.ability.extra.chip_gain
			return {
				message = 'Upgraded!',
				colour = G.C.CHIPS,
				card = card
			}
		end
	end
}

--Locked In
SMODS.Joker {
	key = 'AlLocked',
	loc_txt = {
		name = 'Locked In',
		text = {
			"Gains {C:mult}+#2#{} Mult",
			"for each hand played.",
			"{s:0.8,C:inactive}(Currently {s:0.8,C:mult}+#1#{s:0.8,C:inactive} Mult)"
		}
	},
	config = { extra = { mult = 0, mult_gain = 5 } },
	rarity = 2,
	atlas = 'ALJO',
	pos = { x = 3, y = 0 },
	cost = 5,
	unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
	loc_vars = function(self, info_queue, card)
		return { vars = { card.ability.extra.mult, card.ability.extra.mult_gain } }
	end,
	calculate = function(self, card, context)
		if context.joker_main then
			return {
				mult_mod = card.ability.extra.mult,
				message = localize { type = 'variable', key = 'a_mult', vars = { card.ability.extra.mult } }
			}
		end
		if context.before and not context.blueprint then
			card.ability.extra.mult = card.ability.extra.mult + card.ability.extra.mult_gain
			return {
				message = 'Upgraded!',
				colour = G.C.MULT,
				card = card
			}
		end
	end
}

--Wizard Friend
SMODS.Joker {
	key = 'AlWiz',
	loc_txt = {
		name = 'Wizard Friend',
		text = {
			"{C:mult}+#1# {}Mult",
			"{s:0.8}He's trying his best.{}"
		}
	},
	config = { extra = { mult = 2 } },
	loc_vars = function(self, info_queue, card)
		return { vars = { card.ability.extra.mult } }
	end,
	rarity = 1,
	atlas = 'ALJO',
	pos = { x = 5, y = 0 },
	cost = 1,
	unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
	calculate = function(self, card, context)
		if context.joker_main then
			return {
				mult_mod = card.ability.extra.mult,
				message = localize { type = 'variable', key = 'a_mult', vars = { card.ability.extra.mult } }
			}
		end
	end
}

--Gobin
SMODS.Joker {
	key = 'AlGobin',
	loc_txt = {
		name = 'Gobin',
		text = {
			"{C:mult}+#1# {} Mult"
		}
	},

	config = { extra = { mult = 20 } },
	loc_vars = function(self, info_queue, card)
		return { vars = { card.ability.extra.mult } }
	end,
	rarity = 1,
	atlas = 'ALJO',
	pos = { x = 0, y = 1 },
	cost = 5,
	unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
	calculate = function(self, card, context)
		if context.joker_main then
			return {
				mult_mod = card.ability.extra.mult,
				message = localize { type = 'variable', key = 'a_mult', vars = { card.ability.extra.mult } }
			}
		end
	end
}

--Stickman Jim
SMODS.Joker {
	key = 'AlStickman',
	loc_txt = {
		name = 'Stickman Jim',
		text = {
			"{C:chips}+#1# {} Chips."
		}
	},
	config = { extra = { chips = 100 } },
	loc_vars = function(self, info_queue, card)
		return { vars = { card.ability.extra.chips } }
	end,
	rarity = 2,
	atlas = 'ALJO',
	pos = { x = 1, y = 1 },
	cost = 4,
	unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
	calculate = function(self, card, context)
		if context.joker_main then
			return {
				chip_mod = card.ability.extra.chips,
				message = localize { type = 'variable', key = 'a_chips', vars = { card.ability.extra.chips } }
			}
		end
	end
}

--Rock Collection (Code stolen from undertale deltarune mod)
SMODS.Joker {
	key = "AlRocks",
	loc_txt = {
		name = "Rock Collection",
		text = {
			"{C:chips}+#1#{} Chips for each played {C:spades}Spade{} card",
			"{X:mult,C:white}X#2#{} Mult for each played {C:hearts}Heart{} card",
			"{C:mult}+#3#{} Mult for each played {C:clubs}Club{} card",
			"{C:money}$#4#{} for each played {C:diamonds}Diamond{} card"
		}
	},
	config = {
			chips = 50,
			xmult = 1.5,
			mult = 7,
			bigbucks = 1,
	},
	rarity = 3,
	blueprint_compat = true,
	eternal_compat = true,
	atlas = "ALJO",
	pos = { x = 2, y = 1 },
	cost = 7,
	loc_vars = function(self, info_queue, card)
		return { vars = {
			card.ability.chips,
			card.ability.xmult,
			card.ability.mult,
			card.ability.bigbucks,
		} }
	end,
	calculate = function(self, card, context)
		if context.individual and context.cardarea == G.play then
			local result = {}
			if context.other_card:is_suit("Spades") or SMODS.has_any_suit(context.other_card) then
				result["chips"] = card.ability.chips
			end
			if context.other_card:is_suit("Hearts") or SMODS.has_any_suit(context.other_card) then
				result["xmult"] = card.ability.xmult
			end
			if context.other_card.base.suit == "Clubs" or SMODS.has_any_suit(context.other_card) then
				result["mult"] = card.ability.mult
			end
			if context.other_card.base.suit == "Diamonds" or SMODS.has_any_suit(context.other_card) then
				result["dollars"] = card.ability.bigbucks
			end
			return result
		end
	end
}

--rekoJ
SMODS.Joker {
	key = 'AlrekoJ',
	loc_txt = {
		name = 'rekoJ',
		text = {
			"tluM {C:mult}#1#+{}"
		}
	},

	config = { extra = { mult = 4 } },
	loc_vars = function(self, info_queue, card)
		return { vars = { card.ability.extra.mult } }
	end,
	rarity = 1,
	atlas = 'ALJO',
	pos = { x = 3, y = 1 },
	cost = 5,
	unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
	calculate = function(self, card, context)
		if context.joker_main then
			return {
				mult_mod = card.ability.extra.mult,
				message = localize { type = 'variable', key = 'a_mult', vars = { card.ability.extra.mult } }
			}
		end
	end
}

--Twoprint (more code stolen from undertale deltarune)
SMODS.Joker {
	key = "AlTwoPrint",
	loc_txt = {
		name = "Twoprint",
		text = {
			"Copies abilities of {C:attention}Jokers{}",
			"to the left and right"
		},
	},
	config = {
		in_build = false,
		redprint_compat_string = "incompatible"
	},
	unlocked = true,
	rarity = 3,
	blueprint_compat = true,
	eternal_compat = true,
	atlas = "ALJO",
	pos = { x = 4, y = 1 },
	cost = 12,
	loc_vars = function(self, info_queue, card)
		if card.ability.in_build then
			local main_end = {
				{n=G.UIT.C, config={align = "bm", minh = 0.4}, nodes={
					{n=G.UIT.C, config={ref_table = card, align = "m", colour = G.C.JOKER_GREY, r = 0.05, padding = 0.075, func = 'redprint_compat'}, nodes={
						{n=G.UIT.T, config={ref_table = card.ability, ref_value = 'redprint_compat_string',colour = G.C.UI.TEXT_LIGHT, scale = 0.32*0.8}},
					}}
				}}
			}
			return {
				main_end = main_end
			}
		end
	end,
	redprint_compat_check = function(card)
		local left_joker = nil
		local right_joker = nil
		for i = 1, #G.jokers.cards do
			if G.jokers.cards[i] == card then
				left_joker = G.jokers.cards[i-1]
				right_joker = G.jokers.cards[i+1]
			end
		end
		local left_compat = left_joker and left_joker.config.center.blueprint_compat
		local right_compat = right_joker and right_joker.config.center.blueprint_compat
		return {
			left = left_compat,
			right = right_compat
		}
	end,
	add_to_deck = function(self, card, from_debuff)
		card.ability.in_build = true
	end,
	remove_from_deck = function(self, card, from_debuff)
		card.ability.in_build = false
	end,
	calculate = function(self, card, context)
		local left_joker = nil
		local right_joker = nil
		for i = 1, #G.jokers.cards do
			if G.jokers.cards[i] == card then
				left_joker = G.jokers.cards[i-1]
				right_joker = G.jokers.cards[i+1]
			end
		end
		local left_joker_results = SMODS.blueprint_effect(card, left_joker, context)
		local right_joker_results = SMODS.blueprint_effect(card, right_joker, context)
		local results = SMODS.merge_effects({left_joker_results or {}, right_joker_results or {}})
		return results
	end
}

G.FUNCS.redprint_compat = function(e)
	local results = e.config.ref_table.config.center.redprint_compat_check(e.config.ref_table)
	if results["left"] and not results["right"] then
		e.config.ref_table.ability.redprint_compat_string = "left "..localize("k_compatible")
		e.config.colour = mix_colours(G.C.GOLD, G.C.JOKER_GREY, 0.8)
	elseif results["right"] and not results["left"] then
		e.config.ref_table.ability.redprint_compat_string = "right "..localize("k_compatible")
		e.config.colour = mix_colours(G.C.GOLD, G.C.JOKER_GREY, 0.8)
	elseif results["right"] and results["left"] then
		e.config.ref_table.ability.redprint_compat_string = localize("k_compatible")
		e.config.colour = mix_colours(G.C.GREEN, G.C.JOKER_GREY, 0.8)
	else
		e.config.ref_table.ability.redprint_compat_string = localize("k_incompatible")
		e.config.colour = mix_colours(G.C.RED, G.C.JOKER_GREY, 0.8)
	end
end

--Lucky 7's
SMODS.Joker {
	key = 'AlSeven',
	loc_txt = {
		name = "Lucky Seven",
		text = {
			"Each played {C:attention}7{}",
			"gives {C:gold}$#1#{} and",
			"{C:mult}+#2#{} Mult when scored"
		}
	},
	config = { extra = { money = 5, mult = 5 } },
	rarity = 1,
	atlas = 'ALJO',
	pos = { x = 5, y = 1 },
	cost = 4,
	blueprint_compat = true,
	loc_vars = function(self, info_queue, card)
		return { vars = { card.ability.extra.money, card.ability.extra.mult } }
	end,
	calculate = function(self, card, context)
		if context.individual and context.cardarea == G.play then
			-- :get_id tests for the rank of the card. Other than 2-10, Jack is 11, Queen is 12, King is 13, and Ace is 14.
			if context.other_card:get_id() == 7 then
				-- Specifically returning to context.other_card is fine with multiple values in a single return value, chips/mult are different from chip_mod and mult_mod, and automatically come with a message which plays in order of return.
				return {
					dollars = card.ability.extra.money,
					mult = card.ability.extra.mult,
					card = context.other_card
				}
			end
		end
	end
}

--Fancy Ace
SMODS.Joker {
	key = 'AlAce',
	loc_txt = {
		name = "Fancy Ace",
		text = {
			"Each played {C:attention}Ace{}",
			"gives {C:chips}#1#{}, chips",
			"{C:mult}+#2#{} Mult",
			"and {X:mult,C:white}X#3#{} Mult when scored"
		}
	},
	config = { extra = { chips = 5, mult = 5, Xmult = 1.5 } },
	rarity = 2,
	atlas = 'ALJO',
	pos = { x = 0, y = 2 },
	cost = 4,
	blueprint_compat = true,
	loc_vars = function(self, info_queue, card)
		return { vars = { card.ability.extra.chips, card.ability.extra.mult, card.ability.extra.Xmult } }
	end,
	calculate = function(self, card, context)
		if context.individual and context.cardarea == G.play then
			-- :get_id tests for the rank of the card. Other than 2-10, Jack is 11, Queen is 12, King is 13, and Ace is 14.
			if context.other_card:get_id() == 14 then
				-- Specifically returning to context.other_card is fine with multiple values in a single return value, chips/mult are different from chip_mod and mult_mod, and automatically come with a message which plays in order of return.
				return {
					chips = card.ability.extra.chips,
					mult = card.ability.extra.mult,
					Xmult_mod = card.ability.extra.Xmult,
					card = context.other_card
				}
			end
		end
	end
}

--Game Card
SMODS.Joker {
	key = 'AlGameCard',
	loc_txt = {
		name = 'Game Card',
		text = {
			"Gains {C:mult}+2{} Mult",
			"for each game Alx10k has on Steam.",
			"{s:0.8,C:inactive}(Currently {s:0.8,C:mult}+#1#{s:0.8,C:inactive} Mult)"
		}
	},
	config = { extra = { mult = 122 } },
	loc_vars = function(self, info_queue, card)
		return { vars = { card.ability.extra.mult } }
	end,
	rarity = 1,
	atlas = 'ALJO',
	pos = { x = 1, y = 2 },
	cost = 5,
	unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
	calculate = function(self, card, context)
		if context.joker_main then
			return {
				mult_mod = card.ability.extra.mult,
				message = localize { type = 'variable', key = 'a_mult', vars = { card.ability.extra.mult } }
			}
		end
	end
}

--Job Application
SMODS.Joker{
	key = "AlJob",
	loc_txt = {
		name = "Job Application",
		text = {
			"{C:green} 1 in #2#{} chance to",
			"earn {C:attention}$#1#{} when a hand is played."
		}
	},
	atlas = "ALJO",
	pos = {x = 2, y = 2},
	config = {extra = {dollars = 20, chance = 14}},
	loc_vars = function(self,info_queue,center)
		return { vars = {center.ability.extra.dollars, center.ability.extra.chance}}
	end,
	calculate = function (self,card,context)
	if context.joker_main and
		pseudorandom("JobApplication") < (G.GAME.probabilities.normal / card.ability.extra.chance) then
			return {
				card = card,
				dollars = card.ability.extra.dollars,
				color = G.C.GOLD,
				message = "Paid!"
			}
		elseif context.joker_main then
			return {
				card = card,
				message = "Unpaid..."
			}
		end
		
	end
}

--Crash
SMODS.Joker {
	key = 'AlCrash',
	loc_txt = {
		name = 'Crash',
		text = {
			"Crashes the game",
			"when a hand is played.",
			"{s:0.8}Why would you want this?{}"
		}
	},
	config = { extra = { repetitions = 1 } },
	rarity = 2,
	atlas = 'ALJO',
	pos = { x = 3, y = 2 },
	cost = 6,
	calculate = function(self, card, context)
		if context.cardarea == G.play and context.repetition and not context.repetition_only then
			if context.other_card:is_lucky() then
				return {
					message = 'Again!',
					repetitions = card.ability.extra.repetitions,
					card = context.other_card
				}
			end
		end
	end
}

--true invis joker
SMODS.Joker {
	key = 'AlInvis',
	loc_txt = {
		name = 'True Invisible Joker',
		text = {
			"{C:mult}+#1# {} Mult",
			"{s:0.8}You sure that's not air?{}"
		}
	},
	config = { extra = { mult = 200 } },
	loc_vars = function(self, info_queue, card)
		return { vars = { card.ability.extra.mult } }
	end,
	rarity = 3,
	atlas = 'ALJO',
	pos = { x = 5, y = 2 },
	cost = 6,
	unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
	calculate = function(self, card, context)
		if context.joker_main then
			return {
				mult_mod = card.ability.extra.mult,
				message = localize { type = 'variable', key = 'a_mult', vars = { card.ability.extra.mult } }
			}
		end
	end
}

--Astro
SMODS.Joker{
    key = 'AlAstro',
    loc_txt= {
        name = 'Astro',
        text = { "Creates the {C:attention}planet card{}",
                    "of your most played hand {C:attention}every blind{}",
                    "Creates a {C:attention}Black Hole{} on boss blind.",
                    "{C:inactive}(Must have room){}",
    },},
    atlas = 'ALJO',
    rarity = 4,
    cost = 20,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = false,
    perishable_compat = false,
    pos = {x=0, y= 3},
	soul_pos = {x=0, y=4},
    config = { extra = {active = true}},
    loc_vars = function(self, info_queue, center)
		return { vars = { center.ability.extra.active }  }
	end,
    active = true,
    calculate = function(self, card, context)
        if context.setting_blind and #G.consumeables.cards + G.GAME.consumeable_buffer < G.consumeables.config.card_limit then
            local card_type = 'Planet'
            local _planet = 0
            for k, v in pairs(G.P_CENTER_POOLS.Planet) do
                if v.config.hand_type == G.GAME.current_round.most_played_poker_hand then
                    _planet = v.key
                end
            end
            if G.GAME.blind:get_type() ~= 'Boss' then
                local card = create_card(nil, G.consumeables, nil, nil, nil, nil, _planet, 'Spaceman')
                card:add_to_deck()
                G.consumeables:emplace(card)
                active = false
                return{message = "Planet Found!"}
            else
                local card = create_card(nil, G.consumeables, nil, nil, nil, nil, 'c_black_hole', 'Spaceman')
                card:add_to_deck()
                G.consumeables:emplace(card)
                active = false
                return{message = "Black Hole Found!"}
            end
            
        end
    end,
}

--Bob
 SMODS.Joker {
	key = 'ALBob',
	loc_txt = {
		name = 'Bob',
		text = {
			"He doesn't do anything."
		}
	},
	config = { extra = { money = -1 } },
	rarity = 4,
	unlocked = true,
    discovered = true,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = false,
	atlas = 'ALJO',
	pos = { x = 1, y = 3 },
	soul_pos = { x = 1, y = 4},
	cost = 0,
	loc_vars = function(self, info_queue, card)
		return { vars = { card.ability.extra.money } }
	end,
}

--Gold D
SMODS.Joker {
	key = 'AlGoldD',
	loc_txt = {
		name = 'Gold D',
		text = {
			"Each played card",
			"gives {C:money}$#1#{} ",
			"when scored."
		}
	},
	config = { extra = { money = 5 } },
	rarity = 4,
	atlas = 'ALJO',
	pos = { x = 2, y = 3 },
	soul_pos = {x = 2, y = 4},
	cost = 20,
	unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
	loc_vars = function(self, info_queue, card)
		return { vars = { card.ability.extra.money } }
	end,
	calculate = function(self, card, context)
		if context.individual and context.cardarea == G.play then
			if context.other_card:is_face() then
				return {
					dollars = card.ability.extra.money,
					card = context.other_card
				}
			else
				return {
					dollars = card.ability.extra.money,
					card = context.other_card
				}
			end
		end
	end
}

--Gregg
SMODS.Joker {
	key = 'AlGregg',
	loc_txt = {
		name = 'Gregg',
		text = {
			"Gains {X:mult,C:white}X#2#{} XMult",
			"for each hand played.",
			"{s:0.8,C:inactive}(Currently {s:0.8,X:mult,C:white}X#1#{s:0.8,C:inactive} Mult)"
		}
	},
	config = { extra = { Xmult = 0, Xmult_gain = 1 } },
	rarity = 4,
	atlas = 'ALJO',
	pos = { x = 3, y = 3 },
	soul_pos = { x = 3, y = 4},
	cost = 20,
	unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
	loc_vars = function(self, info_queue, card)
		return { vars = { card.ability.extra.Xmult, card.ability.extra.Xmult_gain } }
	end,
	calculate = function(self, card, context)
		if context.joker_main then
			return {
				Xmult_mod = card.ability.extra.Xmult,
				message = localize { type = 'variable', key = 'a_xmult', vars = { card.ability.extra.Xmult } }
			}
		end
		if context.before and not context.blueprint then
			card.ability.extra.Xmult = card.ability.extra.Xmult + card.ability.extra.Xmult_gain
			return {
				message = 'Upgraded!',
				colour = G.C.MULT,
				card = card
			}
		end
	end
}

--Jevil
SMODS.Joker {
	key = 'AlJevil',
	loc_txt = {
		name = 'Jevil',
		text = {
			"Each played card",
			"gives {X:mult,C:white}X#1#{} Mult",
			"when scored."
		}
	},
	config = { extra = { Xmult = 2 } },
	rarity = 4,
	atlas = 'ALJO',
	unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
	pos = { x = 4, y = 3 },
	soul_pos = {x = 4, y = 4},
	cost = 20,
	loc_vars = function(self, info_queue, card)
		return { vars = { card.ability.extra.Xmult } }
	end,
	calculate = function(self, card, context)
		if context.individual and context.cardarea == G.play then
			if context.other_card:is_face() then
				return {
					Xmult = card.ability.extra.Xmult,
					card = context.other_card
				}
			else
				return {
					Xmult = card.ability.extra.Xmult,
					card = context.other_card
				}
			end
		end
	end
}

--Jimbo
 SMODS.Joker {
	key = 'ALJimbo',
	loc_txt = {
		name = 'Jimbo',
		text = {
			"Retrigger all",
			"played cards,{C:attention} twice."
		}
	},
	config = { extra = { repetitions = 2 } },
	rarity = 4,
	atlas = 'ALJO',
	pos = { x = 5, y = 3 },
	soul_pos = {x = 5, y = 4},
	cost = 20,
	unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
	calculate = function(self, card, context)
		if context.cardarea == G.play and context.repetition and not context.repetition_only then
			if context.other_card:is_face() then
				return {
					message = 'Again!',
					repetitions = card.ability.extra.repetitions,
					-- The card the repetitions are applying to is context.other_card
					card = context.other_card
				}
			else
				return {
					message = 'Again!',
					repetitions = card.ability.extra.repetitions,
					-- The card the repetitions are applying to is context.other_card
					card = context.other_card
				}
			end
		end
	end
}